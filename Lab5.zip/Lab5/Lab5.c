#include<stdio.h>
#include "msp.h"
#include "uart.h"

#define CHAR_COUNT 10      //change this to modify the max. permissible length of a sentence
void LED1_Init(void);
void LED2_Init(void);

